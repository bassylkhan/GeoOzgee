// Main JavaScript File - Initialize all components
document.addEventListener('DOMContentLoaded', () => {
  // Set up placeholder profile image
  const profileImage = document.querySelector('.profile-icon img');
  if (profileImage) {
    profileImage.src = 'https://images.pexels.com/photos/1766604/pexels-photo-1766604.jpeg?auto=compress&cs=tinysrgb&w=300';
    profileImage.onerror = function() {
      this.src = 'data:image/svg+xml;charset=UTF-8,%3Csvg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="%23FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"%3E%3Cpath d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"%3E%3C/path%3E%3Ccircle cx="12" cy="7" r="4"%3E%3C/circle%3E%3C/svg%3E';
    };
  }

  // Create img directory if needed
  const imgDir = document.createElement('div');
  imgDir.style.display = 'none';
  imgDir.id = 'img-directory';
  document.body.appendChild(imgDir);

  // Make links smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 70, // Offset for header
          behavior: 'smooth'
        });
      }
    });
  });

  // Update the page title
  document.title = 'GeoOzge - Learn Geography';

  // Handle window resize for responsive adjustments
  window.addEventListener('resize', handleResponsiveLayout);
  handleResponsiveLayout();

  // Set interval to check and update achievements
  setInterval(() => {
    const profilePoints = document.getElementById('profile-points');
    const points = parseInt(profilePoints.textContent);
    checkAchievements(points);
  }, 60000); // Check every minute
});

// Handle responsive layout adjustments
function handleResponsiveLayout() {
  const mainContent = document.querySelector('.main-content');
  
  if (window.innerWidth <= 768) {
    // Mobile layout adjustments
    mainContent.style.flexDirection = 'column';
    
    // Make flashcards taller on mobile
    const flashcard = document.querySelector('.flashcard');
    if (flashcard) {
      flashcard.style.height = '180px';
    }
    
    // Reduce padding on mobile
    document.querySelectorAll('.section-container').forEach(section => {
      section.style.padding = 'var(--spacing-3)';
    });
  } else {
    // Desktop/tablet layout
    mainContent.style.flexDirection = 'row';
    
    // Reset flashcard height
    const flashcard = document.querySelector('.flashcard');
    if (flashcard) {
      flashcard.style.height = '200px';
    }
    
    // Reset padding
    document.querySelectorAll('.section-container').forEach(section => {
      section.style.padding = 'var(--spacing-4)';
    });
  }
}