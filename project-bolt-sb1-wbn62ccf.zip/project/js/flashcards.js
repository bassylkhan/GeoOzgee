// Flashcards Functionality
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const flashcard = document.querySelector('.flashcard');
  const cardQuestion = document.getElementById('card-question');
  const cardAnswer = document.getElementById('card-answer');
  const prevButton = document.getElementById('prev-card');
  const nextButton = document.getElementById('next-card');
  const continentFilter = document.getElementById('continent-filter');
  const progressFill = document.getElementById('progress-fill');
  const cardsCompleted = document.getElementById('cards-completed');
  const cardsTotal = document.getElementById('cards-total');
  const countdownEl = document.getElementById('countdown');
  const countdownCircle = document.querySelector('.countdown-circle-fg');
  
  // State
  let currentContinent = 'world';
  let currentCards = [];
  let currentCardIndex = 0;
  let countdownTimer = null;
  let cardsStudied = 0;
  
  // Get all countries based on continent filter
  function getFilteredCountries() {
    if (currentContinent === 'world') {
      // Combine all continents
      let allCountries = [];
      for (const continent in geographyData.countries) {
        allCountries = allCountries.concat(geographyData.countries[continent]);
      }
      return allCountries;
    } else {
      return geographyData.countries[currentContinent];
    }
  }
  
  // Initialize flashcards
  function initFlashcards() {
    currentCards = getFilteredCountries();
    currentCardIndex = 0;
    updateCardDisplay();
    updateProgress();
  }
  
  // Update the flashcard display
  function updateCardDisplay() {
    if (currentCards.length === 0) return;
    
    const currentCard = currentCards[currentCardIndex];
    
    // Remove any existing classes that might be leftover
    flashcard.classList.remove('flipped');
    
    // Add a slight animation effect for new card
    flashcard.querySelector('.flashcard-inner').classList.remove('new-card');
    void flashcard.querySelector('.flashcard-inner').offsetWidth; // Force reflow
    flashcard.querySelector('.flashcard-inner').classList.add('new-card');
    
    // Update content
    cardQuestion.textContent = currentCard.country;
    cardAnswer.textContent = currentCard.capital;
    
    // Clear any existing countdown
    if (countdownTimer) {
      clearInterval(countdownTimer);
      countdownTimer = null;
    }
    
    // Reset countdown circle
    countdownCircle.style.strokeDashoffset = '0';
  }
  
  // Update progress bar
  function updateProgress() {
    const percentage = currentCards.length > 0 
      ? ((currentCardIndex + 1) / currentCards.length) * 100 
      : 0;
      
    progressFill.style.width = `${percentage}%`;
    cardsCompleted.textContent = currentCardIndex + 1;
    cardsTotal.textContent = currentCards.length;
  }
  
  // Start countdown after card flip
  function startCountdown() {
    let count = 3;
    countdownEl.textContent = count;
    
    // Reset animation
    countdownCircle.style.transition = 'none';
    countdownCircle.style.strokeDashoffset = '0';
    void countdownCircle.offsetWidth; // Force reflow
    
    // Start animation
    countdownCircle.style.transition = 'stroke-dashoffset 3s linear';
    countdownCircle.style.strokeDashoffset = '173'; // Full circle (2πr where r=28)
    
    if (countdownTimer) {
      clearInterval(countdownTimer);
    }
    
    countdownTimer = setInterval(() => {
      count--;
      countdownEl.textContent = count;
      
      if (count <= 0) {
        clearInterval(countdownTimer);
        nextCard();
      }
    }, 1000);
  }
  
  // Go to next card
  function nextCard() {
    if (currentCards.length === 0) return;
    
    // Only increment cards studied if the card was flipped
    if (flashcard.classList.contains('flipped')) {
      cardsStudied++;
      
      // Update profile
      const profileCards = document.getElementById('profile-cards');
      profileCards.textContent = cardsStudied;
      
      // Add points
      addPoints(1);
    }
    
    // Clear countdown
    if (countdownTimer) {
      clearInterval(countdownTimer);
      countdownTimer = null;
    }
    
    currentCardIndex = (currentCardIndex + 1) % currentCards.length;
    updateCardDisplay();
    updateProgress();
  }
  
  // Go to previous card
  function prevCard() {
    if (currentCards.length === 0) return;
    
    // Clear countdown
    if (countdownTimer) {
      clearInterval(countdownTimer);
      countdownTimer = null;
    }
    
    currentCardIndex = (currentCardIndex - 1 + currentCards.length) % currentCards.length;
    updateCardDisplay();
    updateProgress();
  }
  
  // Event Listeners
  flashcard.addEventListener('click', () => {
    if (!flashcard.classList.contains('flipped')) {
      flashcard.classList.add('flipped');
      startCountdown();
    }
  });
  
  prevButton.addEventListener('click', (e) => {
    e.preventDefault();
    prevCard();
  });
  
  nextButton.addEventListener('click', (e) => {
    e.preventDefault();
    nextCard();
  });
  
  continentFilter.addEventListener('change', () => {
    currentContinent = continentFilter.value;
    initFlashcards();
  });
  
  // Initialize
  initFlashcards();
  
  // Export functions for other modules
  window.flashcards = {
    incrementCardsStudied: () => {
      cardsStudied++;
      const profileCards = document.getElementById('profile-cards');
      profileCards.textContent = cardsStudied;
    }
  };
});

// Function to add points (shared across modules)
function addPoints(points) {
  const profilePoints = document.getElementById('profile-points');
  const currentPoints = parseInt(profilePoints.textContent);
  const newPoints = currentPoints + points;
  
  profilePoints.textContent = newPoints;
  
  // Check for achievement unlock
  checkAchievements(newPoints);
}

// Check if any achievements are unlocked
function checkAchievements(currentPoints) {
  const profileTitle = document.getElementById('profile-title');
  const achievements = geographyData.achievements;
  
  // Find the highest achievement the user qualifies for
  let newTitle = achievements[0].title; // Default to the lowest title
  
  for (let i = achievements.length - 1; i >= 0; i--) {
    if (currentPoints >= achievements[i].points) {
      newTitle = achievements[i].title;
      break;
    }
  }
  
  // Update title if it's changed
  if (profileTitle.textContent !== newTitle) {
    profileTitle.textContent = newTitle;
    profileTitle.classList.remove('achievement-unlocked');
    void profileTitle.offsetWidth; // Force reflow
    profileTitle.classList.add('achievement-unlocked');
    
    // Show achievement notification
    showAchievementNotification(newTitle);
  }
}

// Show achievement notification
function showAchievementNotification(title) {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = 'achievement-notification';
  notification.innerHTML = `
    <h3>Achievement Unlocked!</h3>
    <p>You've earned the title: <strong>${title}</strong></p>
  `;
  
  // Style the notification
  notification.style.position = 'fixed';
  notification.style.bottom = '20px';
  notification.style.right = '20px';
  notification.style.backgroundColor = 'var(--primary-color)';
  notification.style.color = 'white';
  notification.style.padding = '15px 20px';
  notification.style.borderRadius = 'var(--border-radius-md)';
  notification.style.boxShadow = 'var(--shadow-lg)';
  notification.style.zIndex = '1000';
  notification.style.animation = 'achievementUnlocked 0.5s, fadeOut 0.5s 4.5s forwards';
  
  // Add to document
  document.body.appendChild(notification);
  
  // Remove after 5 seconds
  setTimeout(() => {
    document.body.removeChild(notification);
  }, 5000);
}