// Geography data for the website
const geographyData = {
  // Countries and capitals organized by continent
  countries: {
    africa: [
      { country: "Egypt", capital: "Cairo" },
      { country: "South Africa", capital: "Pretoria (administrative), Cape Town (legislative), Bloemfontein (judicial)" },
      { country: "Nigeria", capital: "Abuja" },
      { country: "Kenya", capital: "Nairobi" },
      { country: "Morocco", capital: "Rabat" },
      { country: "Algeria", capital: "Algiers" },
      { country: "Ethiopia", capital: "Addis Ababa" },
      { country: "Ghana", capital: "Accra" },
      { country: "Tanzania", capital: "Dodoma" },
      { country: "Uganda", capital: "Kampala" }
    ],
    asia: [
      { country: "Japan", capital: "Tokyo" },
      { country: "China", capital: "Beijing" },
      { country: "India", capital: "New Delhi" },
      { country: "Thailand", capital: "Bangkok" },
      { country: "South Korea", capital: "Seoul" },
      { country: "Vietnam", capital: "Hanoi" },
      { country: "Indonesia", capital: "Jakarta" },
      { country: "Malaysia", capital: "Kuala Lumpur" },
      { country: "Singapore", capital: "Singapore" },
      { country: "Philippines", capital: "Manila" }
    ],
    europe: [
      { country: "United Kingdom", capital: "London" },
      { country: "France", capital: "Paris" },
      { country: "Germany", capital: "Berlin" },
      { country: "Italy", capital: "Rome" },
      { country: "Spain", capital: "Madrid" },
      { country: "Portugal", capital: "Lisbon" },
      { country: "Netherlands", capital: "Amsterdam" },
      { country: "Switzerland", capital: "Bern" },
      { country: "Sweden", capital: "Stockholm" },
      { country: "Norway", capital: "Oslo" }
    ],
    northAmerica: [
      { country: "United States", capital: "Washington, D.C." },
      { country: "Canada", capital: "Ottawa" },
      { country: "Mexico", capital: "Mexico City" },
      { country: "Costa Rica", capital: "San José" },
      { country: "Panama", capital: "Panama City" },
      { country: "Jamaica", capital: "Kingston" },
      { country: "Cuba", capital: "Havana" },
      { country: "Dominican Republic", capital: "Santo Domingo" },
      { country: "Guatemala", capital: "Guatemala City" },
      { country: "Haiti", capital: "Port-au-Prince" }
    ],
    southAmerica: [
      { country: "Brazil", capital: "Brasília" },
      { country: "Argentina", capital: "Buenos Aires" },
      { country: "Colombia", capital: "Bogotá" },
      { country: "Peru", capital: "Lima" },
      { country: "Chile", capital: "Santiago" },
      { country: "Ecuador", capital: "Quito" },
      { country: "Venezuela", capital: "Caracas" },
      { country: "Uruguay", capital: "Montevideo" },
      { country: "Paraguay", capital: "Asunción" },
      { country: "Bolivia", capital: "La Paz (administrative), Sucre (constitutional)" }
    ],
    oceania: [
      { country: "Australia", capital: "Canberra" },
      { country: "New Zealand", capital: "Wellington" },
      { country: "Fiji", capital: "Suva" },
      { country: "Papua New Guinea", capital: "Port Moresby" },
      { country: "Solomon Islands", capital: "Honiara" },
      { country: "Samoa", capital: "Apia" },
      { country: "Vanuatu", capital: "Port Vila" },
      { country: "Kiribati", capital: "South Tarawa" },
      { country: "Tonga", capital: "Nukuʻalofa" },
      { country: "Micronesia", capital: "Palikir" }
    ]
  },
  
  // Famous attractions
  attractions: [
    {
      name: "Eiffel Tower",
      country: "France",
      description: "A 330-meter-tall wrought-iron tower in Paris, France. Built in 1889, it's one of the world's most iconic landmarks.",
      image: "https://images.pexels.com/photos/532826/pexels-photo-532826.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      name: "Great Wall of China",
      country: "China",
      description: "An ancient fortification spanning more than 13,000 miles, built to protect Chinese states against nomadic groups.",
      image: "https://images.pexels.com/photos/2412603/pexels-photo-2412603.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      name: "Pyramids of Giza",
      country: "Egypt",
      description: "Ancient pyramid complex near Cairo, including the Great Pyramid, one of the Seven Wonders of the Ancient World.",
      image: "https://images.pexels.com/photos/3290068/pexels-photo-3290068.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      name: "Taj Mahal",
      country: "India",
      description: "An ivory-white marble mausoleum in Agra, built by Emperor Shah Jahan in memory of his favorite wife.",
      image: "https://images.pexels.com/photos/1603650/pexels-photo-1603650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      name: "Machu Picchu",
      country: "Peru",
      description: "An ancient Incan citadel set high in the Andes Mountains, built in the 15th century and later abandoned.",
      image: "https://images.pexels.com/photos/2929906/pexels-photo-2929906.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      name: "Colosseum",
      country: "Italy",
      description: "An ancient amphitheater in Rome, built around 70-80 AD, where gladiatorial contests and other events were held.",
      image: "https://images.pexels.com/photos/532263/pexels-photo-532263.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      name: "Statue of Liberty",
      country: "United States",
      description: "A colossal neoclassical sculpture on Liberty Island in New York Harbor, a gift from France to the United States.",
      image: "https://images.pexels.com/photos/290386/pexels-photo-290386.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      name: "Sydney Opera House",
      country: "Australia",
      description: "A multi-venue performing arts center in Sydney, famous for its distinctive sail-shaped design.",
      image: "https://images.pexels.com/photos/2193300/pexels-photo-2193300.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  
  // Quiz questions
  quizQuestions: [
    {
      question: "Which country has the largest land area in the world?",
      options: ["Canada", "China", "United States", "Russia"],
      answer: "Russia"
    },
    {
      question: "Which of these cities is NOT a capital?",
      options: ["Sydney", "Ottawa", "Vienna", "Madrid"],
      answer: "Sydney"
    },
    {
      question: "The Amazon River is located primarily in which country?",
      options: ["Colombia", "Peru", "Brazil", "Venezuela"],
      answer: "Brazil"
    },
    {
      question: "Mount Everest is located in which mountain range?",
      options: ["Andes", "Rockies", "Alps", "Himalayas"],
      answer: "Himalayas"
    },
    {
      question: "Which country is home to the Great Barrier Reef?",
      options: ["Australia", "Indonesia", "Philippines", "Thailand"],
      answer: "Australia"
    },
    {
      question: "Which desert is the largest in the world?",
      options: ["Gobi Desert", "Kalahari Desert", "Sahara Desert", "Arabian Desert"],
      answer: "Sahara Desert"
    },
    {
      question: "Which of these countries is located in Africa?",
      options: ["Cambodia", "Ecuador", "Slovakia", "Namibia"],
      answer: "Namibia"
    },
    {
      question: "Which strait separates Asia from North America?",
      options: ["Strait of Gibraltar", "Bering Strait", "Strait of Malacca", "Strait of Hormuz"],
      answer: "Bering Strait"
    },
    {
      question: "Which of these countries does NOT have a coastline?",
      options: ["Bolivia", "Norway", "Vietnam", "Italy"],
      answer: "Bolivia"
    },
    {
      question: "The Nile River flows through which country?",
      options: ["Morocco", "Nigeria", "Egypt", "Saudi Arabia"],
      answer: "Egypt"
    },
    {
      question: "Which is the smallest continent by land area?",
      options: ["Europe", "Australia", "Antarctica", "South America"],
      answer: "Australia"
    },
    {
      question: "Which of these countries is an island nation?",
      options: ["Spain", "Japan", "France", "Brazil"],
      answer: "Japan"
    },
    {
      question: "Lake Baikal, the world's deepest lake, is located in which country?",
      options: ["Canada", "Mongolia", "Russia", "Kazakhstan"],
      answer: "Russia"
    },
    {
      question: "Which mountain range runs along the border between France and Spain?",
      options: ["Alps", "Carpathians", "Pyrenees", "Apennines"],
      answer: "Pyrenees"
    },
    {
      question: "Which of these countries is located in the Southern Hemisphere?",
      options: ["Mexico", "India", "New Zealand", "Germany"],
      answer: "New Zealand"
    }
  ],
  
  // Fun geographical facts
  funFacts: [
    "Russia spans 11 time zones, more than any other country in the world.",
    "The Sahara Desert used to be a lush savannah with lakes and abundant wildlife just 6,000 years ago.",
    "Vatican City is the world's smallest country, with an area of just 0.44 square kilometers.",
    "The Dead Sea is so salty that people can easily float in it due to the high salt concentration.",
    "Australia is the only continent that is also a country.",
    "Mount Everest grows about 4 millimeters taller every year due to geological uplift.",
    "Alaska has more coastline than all of the other 49 U.S. states combined.",
    "The continent of Antarctica holds approximately 70% of Earth's fresh water in its ice sheet.",
    "The Pacific Ocean is so large that all of the world's continents could fit into it with room to spare.",
    "The highest waterfall in the world is Angel Falls in Venezuela, with a height of 979 meters (3,212 feet).",
    "The Nile River, at approximately 6,650 kilometers long, is considered the longest river in the world.",
    "The largest island in the world is Greenland, which belongs to the Kingdom of Denmark.",
    "The driest place on Earth is the Atacama Desert in Chile, where some areas have not received rainfall for 400 years.",
    "Indonesia is made up of more than 17,500 islands, making it the world's largest archipelago.",
    "Lake Baikal in Russia contains about 20% of the world's unfrozen fresh water and is the world's deepest lake.",
    "Singapore is one of only three city-states in the world, the others being Monaco and Vatican City.",
    "The Amazon Rainforest produces approximately 20% of Earth's oxygen, leading it to be called 'the lungs of the planet'.",
    "Iceland sits on two tectonic plates - the North American plate and the Eurasian plate - which are moving apart at about 2.5 centimeters per year.",
    "The world's largest desert is not the Sahara but Antarctica, which is classified as a desert because of its low precipitation.",
    "The longest land border between two countries is between Canada and the United States, spanning approximately 8,891 kilometers."
  ],
  
  // Achievement titles
  achievements: [
    { points: 0, title: "Novice Explorer" },
    { points: 50, title: "Geography Enthusiast" },
    { points: 100, title: "World Traveler" },
    { points: 200, title: "Geography Expert" },
    { points: 350, title: "Atlas Master" },
    { points: 500, title: "Global Scholar" },
    { points: 750, title: "Geography Prodigy" },
    { points: 1000, title: "Professor of Geography" }
  ]
};

// Export data
window.geographyData = geographyData;