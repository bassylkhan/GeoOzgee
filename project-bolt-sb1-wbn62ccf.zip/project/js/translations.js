const translations = {
  en: {
    menu: {
      flashcards: "Flashcards",
      attractions: "Attractions",
      quiz: "Quiz",
      funFacts: "Fun Facts",
      mapGame: "Map Game"
    },
    profile: {
      points: "Points",
      cardsStudied: "Cards Studied",
      registered: "Registered",
      title: "Title"
    },
    flashcards: {
      chooseRegion: "Choose Region",
      world: "World",
      africa: "Africa",
      asia: "Asia",
      europe: "Europe",
      northAmerica: "North America",
      southAmerica: "South America",
      oceania: "Oceania",
      clickToReveal: "Click to reveal the capital",
      previous: "Previous",
      next: "Next"
    },
    quiz: {
      score: "Score",
      question: "Question",
      nextQuestion: "Next Question",
      correct: "Correct! Great job!",
      incorrect: "Incorrect. The correct answer is"
    },
    mapGame: {
      find: "Find",
      capitalOf: "the capital of",
      yourGuess: "Your guess",
      score: "Score",
      average: "Average"
    }
  },
  ru: {
    menu: {
      flashcards: "Карточки",
      attractions: "Достопримечательности",
      quiz: "Викторина",
      funFacts: "Интересные факты",
      mapGame: "Игра с картой"
    },
    profile: {
      points: "Очки",
      cardsStudied: "Изучено карточек",
      registered: "Зарегистрирован",
      title: "Звание"
    },
    flashcards: {
      chooseRegion: "Выберите регион",
      world: "Весь мир",
      africa: "Африка",
      asia: "Азия",
      europe: "Европа",
      northAmerica: "Северная Америка",
      southAmerica: "Южная Америка",
      oceania: "Океания",
      clickToReveal: "Нажмите, чтобы увидеть столицу",
      previous: "Предыдущая",
      next: "Следующая"
    },
    quiz: {
      score: "Счет",
      question: "Вопрос",
      nextQuestion: "Следующий вопрос",
      correct: "Правильно! Отличная работа!",
      incorrect: "Неправильно. Правильный ответ"
    },
    mapGame: {
      find: "Найдите",
      capitalOf: "столицу",
      yourGuess: "Ваш ответ",
      score: "Счет",
      average: "Среднее"
    }
  }
};

// Export translations
window.translations = translations;