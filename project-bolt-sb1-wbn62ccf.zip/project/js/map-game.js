// Map Game Functionality
document.addEventListener('DOMContentLoaded', () => {
  // Initialize map
  const map = L.map('map-game').setView([20, 0], 2);
  
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);
  
  // Game state
  let currentCity = null;
  let score = 0;
  let attempts = 0;
  const maxDistance = 2000; // km
  
  // Get random city
  function getRandomCity() {
    const cities = [];
    for (const continent in geographyData.countries) {
      geographyData.countries[continent].forEach(country => {
        const capital = country.capital.split('(')[0].trim(); // Get primary capital
        cities.push({
          name: capital,
          country: country.country,
          coordinates: geographyData.coordinates[capital]
        });
      });
    }
    return cities[Math.floor(Math.random() * cities.length)];
  }
  
  // Calculate distance between points
  function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
  
  // Start new round
  function startNewRound() {
    currentCity = getRandomCity();
    document.getElementById('current-city').textContent = 
      `Find ${currentCity.name}, the capital of ${currentCity.country}`;
    map.setView([20, 0], 2);
  }
  
  // Handle guess
  map.on('click', (e) => {
    if (!currentCity) return;
    
    const distance = calculateDistance(
      e.latlng.lat,
      e.latlng.lng,
      currentCity.coordinates[0],
      currentCity.coordinates[1]
    );
    
    // Show guess marker
    L.marker(e.latlng).addTo(map)
      .bindPopup('Your guess').openPopup();
    
    // Show actual location
    L.marker([currentCity.coordinates[0], currentCity.coordinates[1]])
      .addTo(map)
      .bindPopup(`${currentCity.name}`).openPopup();
    
    // Draw line between guess and actual location
    L.polyline([
      e.latlng,
      [currentCity.coordinates[0], currentCity.coordinates[1]]
    ], {
      color: 'red',
      dashArray: '5, 10'
    }).addTo(map);
    
    // Calculate score
    const roundScore = Math.max(0, Math.floor((maxDistance - distance) / maxDistance * 100));
    score += roundScore;
    attempts++;
    
    // Update score display
    document.getElementById('map-score').textContent = 
      `Score: ${score} (Average: ${Math.round(score/attempts)})`;
    
    // Add points to profile
    addPoints(roundScore);
    
    // Start new round after delay
    setTimeout(() => {
      map.eachLayer((layer) => {
        if (layer instanceof L.Marker || layer instanceof L.Polyline) {
          map.removeLayer(layer);
        }
      });
      startNewRound();
    }, 3000);
  });
  
  // Initialize first round
  startNewRound();
});