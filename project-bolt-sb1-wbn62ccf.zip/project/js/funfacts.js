// Fun Facts Functionality
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const funFactText = document.getElementById('fun-fact-text');
  const funFactTimer = document.getElementById('fun-fact-timer');
  const timerFill = document.querySelector('.fun-fact-timer .timer-fill');
  
  // State
  let currentFactIndex = 0;
  let factInterval = null;
  let remainingTime = 30;
  
  // Initialize fun facts
  function initFunFacts() {
    // Shuffle the facts
    shuffleArray(geographyData.funFacts);
    
    updateFunFact();
    startFunFactTimer();
  }
  
  // Update the fun fact display
  function updateFunFact() {
    const fact = geographyData.funFacts[currentFactIndex];
    
    // Add fade out effect
    funFactText.style.opacity = '0';
    
    // Change content after fade out
    setTimeout(() => {
      funFactText.textContent = fact;
      
      // Fade in
      funFactText.style.opacity = '1';
    }, 300);
    
    // Update index for next time
    currentFactIndex = (currentFactIndex + 1) % geographyData.funFacts.length;
  }
  
  // Start the fun fact timer
  function startFunFactTimer() {
    // Reset timer animation
    timerFill.style.animation = 'none';
    void timerFill.offsetWidth; // Force reflow
    timerFill.style.animation = 'timerProgress 30s linear forwards';
    
    // Reset counter
    remainingTime = 30;
    funFactTimer.textContent = remainingTime;
    
    // Clear any existing interval
    if (factInterval) {
      clearInterval(factInterval);
    }
    
    // Set new interval
    factInterval = setInterval(() => {
      remainingTime--;
      funFactTimer.textContent = remainingTime;
      
      if (remainingTime <= 0) {
        updateFunFact();
        startFunFactTimer();
      }
    }, 1000);
  }
  
  // Utility function to shuffle an array
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
  
  // Initialize
  initFunFacts();
});