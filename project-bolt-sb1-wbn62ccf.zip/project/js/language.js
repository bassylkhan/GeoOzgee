// Language Functionality
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const languageSelector = document.createElement('select');
  languageSelector.className = 'language-selector';
  
  // Add language options
  const languages = [
    { code: 'en', name: 'English' },
    { code: 'ru', name: 'Русский' }
  ];
  
  languages.forEach(lang => {
    const option = document.createElement('option');
    option.value = lang.code;
    option.textContent = lang.name;
    languageSelector.appendChild(option);
  });
  
  // Add to navigation
  document.querySelector('nav ul').appendChild(languageSelector);
  
  // Set initial language
  const currentLang = localStorage.getItem('language') || 'en';
  languageSelector.value = currentLang;
  updateLanguage(currentLang);
  
  // Handle language change
  languageSelector.addEventListener('change', (e) => {
    const lang = e.target.value;
    localStorage.setItem('language', lang);
    updateLanguage(lang);
  });
});

// Update all text content based on selected language
function updateLanguage(lang) {
  const t = translations[lang];
  
  // Update menu items
  document.querySelector('a[href="#flashcards"]').textContent = t.menu.flashcards;
  document.querySelector('a[href="#attractions"]').textContent = t.menu.attractions;
  document.querySelector('a[href="#quiz"]').textContent = t.menu.quiz;
  document.querySelector('a[href="#fun-facts"]').textContent = t.menu.funFacts;
  
  // Update profile text
  document.querySelector('#profile-points').previousElementSibling.textContent = t.profile.points + ': ';
  document.querySelector('#profile-cards').previousElementSibling.textContent = t.profile.cardsStudied + ': ';
  document.querySelector('#profile-registered').previousElementSibling.textContent = t.profile.registered + ': ';
  document.querySelector('#profile-title').previousElementSibling.textContent = t.profile.title + ': ';
  
  // Update flashcard elements
  document.querySelector('label[for="continent-filter"]').textContent = t.flashcards.chooseRegion + ':';
  document.querySelector('#prev-card').textContent = t.flashcards.previous;
  document.querySelector('#next-card').textContent = t.flashcards.next;
  
  // Update continent options
  const continentFilter = document.querySelector('#continent-filter');
  continentFilter.querySelector('option[value="world"]').textContent = t.flashcards.world;
  continentFilter.querySelector('option[value="africa"]').textContent = t.flashcards.africa;
  continentFilter.querySelector('option[value="asia"]').textContent = t.flashcards.asia;
  continentFilter.querySelector('option[value="europe"]').textContent = t.flashcards.europe;
  continentFilter.querySelector('option[value="northAmerica"]').textContent = t.flashcards.northAmerica;
  continentFilter.querySelector('option[value="southAmerica"]').textContent = t.flashcards.southAmerica;
  continentFilter.querySelector('option[value="oceania"]').textContent = t.flashcards.oceania;
  
  // Update quiz elements
  document.querySelector('.quiz-score').firstChild.textContent = t.quiz.score + ': ';
  document.querySelector('#next-question').textContent = t.quiz.nextQuestion;
  
  // Dispatch custom event for dynamic content
  window.dispatchEvent(new CustomEvent('languageChanged', { detail: { language: lang } }));
}

// Export function for other modules
window.updateLanguage = updateLanguage;