// Attractions Functionality
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const attractionImage = document.getElementById('attraction-image');
  const attractionName = document.getElementById('attraction-name');
  const attractionCountry = document.getElementById('attraction-country');
  const attractionDescription = document.getElementById('attraction-description');
  const attractionTimer = document.getElementById('attraction-timer');
  const timerFill = document.querySelector('.attraction-timer .timer-fill');
  
  // State
  let currentAttractionIndex = 0;
  let attractionInterval = null;
  let remainingTime = 20;
  
  // Initialize attractions
  function initAttractions() {
    updateAttraction();
    startAttractionTimer();
  }
  
  // Update the attraction display
  function updateAttraction() {
    const attraction = geographyData.attractions[currentAttractionIndex];
    
    // Add fade out effect
    attractionImage.style.opacity = '0';
    attractionName.style.opacity = '0';
    attractionCountry.style.opacity = '0';
    attractionDescription.style.opacity = '0';
    
    // Change content after fade out
    setTimeout(() => {
      attractionImage.src = attraction.image;
      attractionName.textContent = attraction.name;
      attractionCountry.textContent = attraction.country;
      attractionDescription.textContent = attraction.description;
      
      // Fade in
      attractionImage.style.opacity = '1';
      attractionName.style.opacity = '1';
      attractionCountry.style.opacity = '1';
      attractionDescription.style.opacity = '1';
    }, 300);
    
    // Update index for next time
    currentAttractionIndex = (currentAttractionIndex + 1) % geographyData.attractions.length;
  }
  
  // Start the attraction timer
  function startAttractionTimer() {
    // Reset timer animation
    timerFill.style.animation = 'none';
    void timerFill.offsetWidth; // Force reflow
    timerFill.style.animation = 'timerProgress 20s linear forwards';
    
    // Reset counter
    remainingTime = 20;
    attractionTimer.textContent = remainingTime;
    
    // Clear any existing interval
    if (attractionInterval) {
      clearInterval(attractionInterval);
    }
    
    // Set new interval
    attractionInterval = setInterval(() => {
      remainingTime--;
      attractionTimer.textContent = remainingTime;
      
      if (remainingTime <= 0) {
        updateAttraction();
        startAttractionTimer();
      }
    }, 1000);
  }
  
  // Event Listeners
  attractionImage.addEventListener('load', () => {
    attractionImage.style.opacity = '1';
  });
  
  // Initialize
  initAttractions();
});