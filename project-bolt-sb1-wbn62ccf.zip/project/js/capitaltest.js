// Capital Test Functionality
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const testCountry = document.getElementById('test-country').querySelector('span');
  const testOptions = document.getElementById('test-options');
  const testResult = document.getElementById('test-result');
  const nextTestButton = document.getElementById('next-test');
  
  // State
  let allCountries = getAllCountries();
  let currentTestIndex = 0;
  let selectedOption = null;
  let isAnswerRevealed = false;
  let correctCapital = '';
  
  // Initialize capital test
  function initCapitalTest() {
    // Shuffle countries
    shuffleArray(allCountries);
    
    // Display first test
    updateTestDisplay();
  }
  
  // Get all countries from all continents
  function getAllCountries() {
    let countries = [];
    for (const continent in geographyData.countries) {
      countries = countries.concat(geographyData.countries[continent]);
    }
    return countries;
  }
  
  // Update the test display
  function updateTestDisplay() {
    const country = allCountries[currentTestIndex];
    
    // Update country name
    testCountry.textContent = country.country;
    correctCapital = country.capital;
    
    // Clear previous options
    testOptions.innerHTML = '';
    
    // Generate options (1 correct, 3 incorrect)
    const options = [correctCapital];
    
    // Add 3 incorrect options
    while (options.length < 4) {
      const randomCountry = allCountries[Math.floor(Math.random() * allCountries.length)];
      if (randomCountry.capital !== correctCapital && !options.includes(randomCountry.capital)) {
        options.push(randomCountry.capital);
      }
    }
    
    // Shuffle options
    shuffleArray(options);
    
    // Add options to the display
    options.forEach(option => {
      const optionElement = document.createElement('div');
      optionElement.className = 'test-option';
      optionElement.textContent = option;
      optionElement.addEventListener('click', () => selectTestOption(optionElement, option));
      testOptions.appendChild(optionElement);
    });
    
    // Reset state
    selectedOption = null;
    isAnswerRevealed = false;
    testResult.style.display = 'none';
    testResult.className = 'test-result';
    nextTestButton.disabled = true;
  }
  
  // Handle option selection
  function selectTestOption(optionElement, option) {
    // Only allow selection if answer isn't revealed yet
    if (isAnswerRevealed) return;
    
    // Clear previous selection
    const options = testOptions.querySelectorAll('.test-option');
    options.forEach(opt => opt.classList.remove('selected'));
    
    // Set new selection
    optionElement.classList.add('selected');
    selectedOption = option;
    
    // Enable next test button
    nextTestButton.disabled = false;
    
    // Check answer
    checkTestAnswer();
  }
  
  // Check if the selected answer is correct
  function checkTestAnswer() {
    if (!selectedOption || isAnswerRevealed) return;
    
    const isCorrect = selectedOption === correctCapital;
    
    // Mark the answer
    const options = testOptions.querySelectorAll('.test-option');
    options.forEach(opt => {
      if (opt.textContent === correctCapital) {
        opt.classList.add('correct');
      } else if (opt.textContent === selectedOption && !isCorrect) {
        opt.classList.add('incorrect');
      }
    });
    
    // Show result message
    testResult.style.display = 'block';
    testResult.classList.add(isCorrect ? 'correct' : 'incorrect');
    testResult.textContent = isCorrect ? 
      'Correct! Great job!' : 
      `Incorrect. The capital of ${allCountries[currentTestIndex].country} is ${correctCapital}.`;
    
    // Award points if correct
    if (isCorrect) {
      addPoints(5);
    }
    
    // Mark answer as revealed
    isAnswerRevealed = true;
  }
  
  // Move to the next test
  function nextTest() {
    currentTestIndex++;
    
    // Check if we've reached the end of the countries
    if (currentTestIndex >= allCountries.length) {
      // Reset for a new round
      currentTestIndex = 0;
      
      // Shuffle countries for the new round
      shuffleArray(allCountries);
    }
    
    // Update display
    updateTestDisplay();
  }
  
  // Utility function to shuffle an array
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
  
  // Event Listeners
  nextTestButton.addEventListener('click', nextTest);
  
  // Initialize
  initCapitalTest();
});