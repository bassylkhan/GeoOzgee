// Profile Functionality
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const profileName = document.getElementById('profile-name');
  const profilePoints = document.getElementById('profile-points');
  const profileCards = document.getElementById('profile-cards');
  const profileRegistered = document.getElementById('profile-registered');
  const profileTitle = document.getElementById('profile-title');
  
  // State
  let userData = loadUserData();
  
  // Initialize profile
  function initProfile() {
    updateProfileDisplay();
  }
  
  // Update the profile display
  function updateProfileDisplay() {
    profileName.textContent = userData.name;
    profilePoints.textContent = userData.points;
    profileCards.textContent = userData.cardsStudied;
    profileRegistered.textContent = userData.registered;
    profileTitle.textContent = userData.title;
  }
  
  // Load user data from localStorage or create default
  function loadUserData() {
    const savedData = localStorage.getItem('geoOzgeUserData');
    
    if (savedData) {
      return JSON.parse(savedData);
    } else {
      // Default user data
      const defaultData = {
        name: 'Guest User',
        points: 0,
        cardsStudied: 0,
        registered: new Date().toLocaleDateString(),
        title: geographyData.achievements[0].title
      };
      
      // Save to localStorage
      localStorage.setItem('geoOzgeUserData', JSON.stringify(defaultData));
      
      return defaultData;
    }
  }
  
  // Save user data to localStorage
  function saveUserData() {
    localStorage.setItem('geoOzgeUserData', JSON.stringify(userData));
  }
  
  // Update points
  window.updateProfilePoints = function(points) {
    userData.points = points;
    profilePoints.textContent = points;
    
    // Check achievements
    const achievements = geographyData.achievements;
    for (let i = achievements.length - 1; i >= 0; i--) {
      if (points >= achievements[i].points) {
        userData.title = achievements[i].title;
        profileTitle.textContent = achievements[i].title;
        break;
      }
    }
    
    saveUserData();
  };
  
  // Update cards studied
  window.updateProfileCards = function(cards) {
    userData.cardsStudied = cards;
    profileCards.textContent = cards;
    saveUserData();
  };
  
  // Initialize
  initProfile();
  
  // Set up interval to save data
  setInterval(saveUserData, 30000); // Save every 30 seconds
});