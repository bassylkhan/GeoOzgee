// Quiz Functionality
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const quizQuestion = document.getElementById('quiz-question-text');
  const quizOptions = document.getElementById('quiz-options');
  const quizResult = document.getElementById('quiz-result');
  const nextQuestionButton = document.getElementById('next-question');
  const quizPoints = document.getElementById('quiz-points');
  const currentQuestionEl = document.getElementById('current-question');
  const totalQuestionsEl = document.getElementById('total-questions');
  
  // State
  let questions = [...geographyData.quizQuestions]; // Make a copy so we can shuffle
  let currentQuestionIndex = 0;
  let selectedOption = null;
  let isAnswerRevealed = false;
  
  // Initialize quiz
  function initQuiz() {
    // Shuffle questions
    shuffleArray(questions);
    
    // Update total questions display
    totalQuestionsEl.textContent = questions.length;
    
    // Display first question
    updateQuestionDisplay();
  }
  
  // Update the question display
  function updateQuestionDisplay() {
    const question = questions[currentQuestionIndex];
    
    // Update question text
    quizQuestion.textContent = question.question;
    
    // Clear previous options
    quizOptions.innerHTML = '';
    
    // Create shuffled options
    const shuffledOptions = [...question.options];
    shuffleArray(shuffledOptions);
    
    // Add options to the display
    shuffledOptions.forEach(option => {
      const optionElement = document.createElement('div');
      optionElement.className = 'quiz-option';
      optionElement.textContent = option;
      optionElement.addEventListener('click', () => selectOption(optionElement, option));
      quizOptions.appendChild(optionElement);
    });
    
    // Update question number
    currentQuestionEl.textContent = currentQuestionIndex + 1;
    
    // Reset state
    selectedOption = null;
    isAnswerRevealed = false;
    quizResult.style.display = 'none';
    quizResult.className = 'quiz-result';
    nextQuestionButton.disabled = true;
  }
  
  // Handle option selection
  function selectOption(optionElement, option) {
    // Only allow selection if answer isn't revealed yet
    if (isAnswerRevealed) return;
    
    // Clear previous selection
    const options = quizOptions.querySelectorAll('.quiz-option');
    options.forEach(opt => opt.classList.remove('selected'));
    
    // Set new selection
    optionElement.classList.add('selected');
    selectedOption = option;
    
    // Enable next question button
    nextQuestionButton.disabled = false;
    
    // Check answer
    checkAnswer();
  }
  
  // Check if the selected answer is correct
  function checkAnswer() {
    if (!selectedOption || isAnswerRevealed) return;
    
    const correctAnswer = questions[currentQuestionIndex].answer;
    const isCorrect = selectedOption === correctAnswer;
    
    // Mark the answer
    const options = quizOptions.querySelectorAll('.quiz-option');
    options.forEach(opt => {
      if (opt.textContent === correctAnswer) {
        opt.classList.add('correct');
      } else if (opt.textContent === selectedOption && !isCorrect) {
        opt.classList.add('incorrect');
      }
    });
    
    // Show result message
    quizResult.style.display = 'block';
    quizResult.classList.add(isCorrect ? 'correct' : 'incorrect');
    quizResult.textContent = isCorrect ? 
      'Correct! Great job!' : 
      `Incorrect. The correct answer is ${correctAnswer}.`;
    
    // Award points if correct
    if (isCorrect) {
      addPoints(10);
    }
    
    // Mark answer as revealed
    isAnswerRevealed = true;
  }
  
  // Move to the next question
  function nextQuestion() {
    currentQuestionIndex++;
    
    // Check if we've reached the end of the questions
    if (currentQuestionIndex >= questions.length) {
      // Reset for a new round
      currentQuestionIndex = 0;
      
      // Shuffle questions for the new round
      shuffleArray(questions);
    }
    
    // Update display
    updateQuestionDisplay();
  }
  
  // Utility function to shuffle an array
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
  
  // Event Listeners
  nextQuestionButton.addEventListener('click', nextQuestion);
  
  // Initialize
  initQuiz();
});